(function(){
    var sort = util.location.queryString('sort', window.location.href);
    if(sort != null && sort != ''){
        sort =  parseInt(sort);
    }else{sort = 3;} //random (3) by default
    download_sort.value = sort;
    download_sort.onInput = function(){
        //update History API
    }
})();

function checkInstances(){
    var i = instances.value;
    if(i != '' && parseInt(i) > 0){
        if(parseInt(i) > 10){
            instances.value = 10;
        }
    }
}

function startDownloads(){
    var i = instances.value;
    if(i != '' && parseInt(i) > 0){
        i = parseInt(i);
        var feedId = feedid ? parseInt(feedid.value) : 0;
        var domain = download_domain ? download_domain.value : '';
        var sort = download_sort ? parseInt(download_sort.value) : 0;
        function next(x){
            var div = document.createElement('div');
            var iframe = document.createElement('iframe');
            var id = 1 + Math.round(9999 * Math.random());
            div.className = 'col instance six'
            iframe.setAttribute('scrolling', 'no');
            iframe.id = 'iframe_' + id;
            iframe.src = window.location.origin + '/download-queue?run&feedid=' + feedId + '&domain=' + 
                (domain != '' ? encodeURIComponent(domain) : '') + '&sort=' + sort + '&iframe=' + id;
            $(div).append(iframe);
            $('.instances').append(div);
            if(x < i){
                setTimeout(() => {next(x+1);}, 500);
            }
        }
        next(1);
    }
}

function stopDownloads(){
    $('.instances').html('');
}