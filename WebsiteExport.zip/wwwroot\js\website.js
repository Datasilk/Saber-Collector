///////////////////////////////////////////////////////////
//global methods
///////////////////////////////////////////////////////////

//simple ajax method
function ajax(url, callback) {
    var req = new XMLHttpRequest();
    req.onload = function () {
        if (req.status >= 200 && req.status < 400 && typeof callback == 'function') {
            callback(req.responseText);
        }
    };
    req.open('GET', url);
    req.send();
}

//logout
function logout(){
    ajax('/logout', () => {
        location.href = '/login';
    });
}

//register dropdown
function dropdown(btn, menu){
    if(!btn || !menu){return;}
    function bodyclick(e){
        var elem = e.target;
        while(elem){
            if(elem == menu){ return; }
            elem = elem.parentNode;
        }
        menu.style.display = 'none';
        document.body.removeEventListener('click', bodyclick)
    }
    btn.addEventListener('click', (e) => {
        if(menu.style.display == 'none'){
            menu.style.display = '';
            setTimeout(() => document.body.addEventListener('click', bodyclick), 10);
        }else{
            bodyclick(e);
        }
    });
}

var util = {
    location: {
        queryString: function (key, url) {
            if (!url) url = window.location.href;
            key = key.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + key + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }
    }
};

var accordion = {
    load: function (options) {
        let opts = {
            container: '.accordion',
            target: '.accordion > .title',
            ontoggle: null,
            opened: false,
        };

        if (options && options.container) { opts.container = options.container; }
        if (options && options.target) { opts.target = options.target; }
        if (options && options.ontoggle) { opts.ontoggle = options.ontoggle; }
        if (options && options.opened) { opts.opened = options.opened; }

        function open(e) {
            if (typeof opts.ontoggle == 'function') {
                opts.ontoggle(e, $(e.target).hasClass('expanded'), opts);
            } else {
                accordion.toggle(e, opts);
            }
        }

        $(opts.target).off('click').on('click', open);

        if (opts.opened == true) {
            $(opts.target).each((i, e) => {
                open({ target: $(e)[0] });
            });
        }

    },

    toggle: function (e, options) {
        $(e.target).parents(options.container).first().toggleClass('expanded');
        $(e.target).parents(options.target).first().toggleClass('expanded');
    }
};

///////////////////////////////////////////////////////////
//initialize website
///////////////////////////////////////////////////////////

//load icons 
ajax('/images/icons.svg', (icons) => {
    var div = document.createElement('div');
    div.innerHTML = icons;
    div.className = 'website-icons svg-icons';
    document.body.appendChild(div);
});

//select top menu item
if($('header').length > 0 && pageid != null && pageid != ''){
    var topmenu = $('header nav .tab-' + pageid)[0];
    if(topmenu){
        topmenu.classList.add('selected');
    }
    
}

//load menus
dropdown($('header .user .icon-user')[0], $('header .user .dropmenu')[0]);

//load accordions
accordion.load();